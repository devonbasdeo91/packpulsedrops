import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'app.packpulsedrops.com',
  appName: 'Pack-Pulse-Drops',
  webDir: 'dist'
};

export default config;
